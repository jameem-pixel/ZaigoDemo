from django.db import models

ACTIVITY = (('A', 'Active'),('D', 'Deleted'))
IMAGE_FOLDER = "employee_images"

class Employee(models.Model):
    employee_id = models.CharField(max_length=255,null=True,blank=True,unique=True,db_index=True)
    first_name = models.CharField(max_length=50,null=True,blank=True)
    last_name = models.CharField(max_length=50,null=True,blank=True)
    email_id = models.EmailField(max_length=50,null=True,blank=True)
    mobile_number = models.CharField(max_length=50,null=True,blank=True)
    profile_photo = models.ImageField(null=True,blank=True,upload_to=IMAGE_FOLDER)
    date_of_birth = models.DateField(auto_now_add=True,null=True,blank=True)
    created_on = models.DateField(auto_now=True,null=True,blank=True)
    updated_on = models.DateField(auto_now=True,null=True,blank=True)
    activity = models.CharField(max_length=8, null=True, blank=True, default='A', choices=ACTIVITY)

    def save(self, *args, **kwargs):
        super(Employee, self).save(*args, **kwargs)
        if not(self.employee_id):
            self.employee_id = "Employee-%04d" % (int(self.id))
            super(Employee, self).save()
        
    def __str__(self):
        return self.employee_id

    class Meta:
        db_table = 'employee'



    




