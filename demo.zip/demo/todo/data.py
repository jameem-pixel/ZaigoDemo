import sys
import datetime
from zoneinfo import ZoneInfo
from rest_framework.response import Response
from django.utils.translation import gettext_lazy as _
from demo import settings
from .import models as app_models
from .import serializers as app_serializers

HTTP_REST_MESSAGES = {"200": _("Success"),
                      "400": _("Failed"),
                      "401": _("Authentication Failed"),
                      "500": _("Internal server error")}


def build_response(status, message, data=dict(), errors=dict()):
    try:
        return Response({'status_code': status, 'message': message, 'data':data,'errors': errors}, status=status)
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))


def convert_date_time_format(date_time, tz_offset=0, date_format=None):
    if date_time:
        if not date_format:
            date_format = settings.DEFAULT_DATE_TIME_FORMAT

        if isinstance(date_time, str):
            date_time = date_time(tz=ZoneInfo('Asia/Kolkata'))
            date_time = datetime.datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S.%f')
        date_time = date_time + datetime.timedelta(hours=5, minutes=30)
        return date_time.strftime("{}".format(settings.DEFAULT_DATE_TIME_FORMAT))
    else:
        return ""

def convert_date_format(date):
    if date:
        return date.strftime("{}".format(settings.DEFAULT_DATE_FORMAT))
    else:
        return ""

def get_employee_list(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        employee_list = app_models.Employee.objects.filter(activity='A')
        serializer = app_serializers.EmployeeListSerializer(employee_list, many=True)
        result, msg, data = True, 'Success', serializer.data
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
    return result, msg, data


def create_employee(request):
    result = False
    msg = 'Error'
    data = dict()
    try:
        pDict = request.POST.copy()
        fDict = request.FILES.copy()
        serializer = app_serializers.EmployeeCreateUpdateSerializer(data=pDict)
        if serializer.is_valid():
            obj = serializer.save()
            employee = app_models.Employee.objects.filter(id=obj.id, activity='A').first()
            if employee:
                employee.profile_photo=fDict.get('profile_photo')
                employee.save()

            result, msg = True, 'Employee Created Successfully'
        else:
            data = serializer.errors
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
    return result, msg, data


def edit_employee(request, employee_id):
    result = False
    msg = 'Error'
    data = dict()
    try:
        employee = app_models.Employee.objects.filter(employee_id=employee_id, activity='A').first()
        if employee:
            pDict = request.POST.copy()
            fDict = request.FILES.copy()
            serializer = app_serializers.EmployeeCreateUpdateSerializer(instance=employee, data=pDict)
            if serializer.is_valid():
                serializer.save()
                obj = serializer.save()
                employee = app_models.Employee.objects.filter(id=obj.id, activity='A').first()
                if employee:
                    employee.profile_photo=fDict.get('profile_photo')
                    employee.save()
                result, msg = True, 'Employee Updated Successfully'
            else:
                data = serializer.errors
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
    return result, msg, data


def delete_employee(employee_id):
    result = False
    msg = 'Error'
    data = dict()
    try:
        employee = app_models.Employee.objects.filter(employee_id=employee_id, activity='A').first()
        if employee:
            employee.activity = 'D'
            employee.save()
            result, msg = True, 'Employee Deleted Successfully'
    except Exception as e:
        exc_type, exc_obj, exc_traceback = sys.exc_info()
        print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
    return result, msg, data
