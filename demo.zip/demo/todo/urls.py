from django.urls import path
from . import views
urlpatterns = [

    path('employee-list/', views.EmployeeView.as_view(), name='employee_list'),
    path('employee-create/', views.EmployeeView.as_view(), name='employee_create'),
    path('employee-edit/<employee_id>/', views.EmployeeView.as_view(), name='employee_edit'),
    path('employee-delete/<employee_id>/', views.EmployeeView.as_view(), name='employee_delete'),
]