import json
from demo import settings
from rest_framework import serializers
from .import models as app_models
from .import data as api_data


class EmployeeListSerializer(serializers.ModelSerializer):
    date_of_birth = serializers.SerializerMethodField(read_only=True)
    created_on = serializers.SerializerMethodField(read_only=True)
    updated_on = serializers.SerializerMethodField(read_only=True)
    image_url = serializers.SerializerMethodField(read_only=True)

    def get_created_on(self, data):
        return api_data.convert_date_time_format(data.created_on)

    def get_updated_on(self, data):
        return api_data.convert_date_time_format(data.updated_on)

    def get_image_url(self, data):
        image_url = settings.APP_URL+settings.MEDIA_URL + str(data.profile_photo)
        return image_url
    
    def get_date_of_birth(self, data):
        return api_data.convert_date_format(data.date_of_birth)

    class Meta:
        model = app_models.Employee
        fields = ['employee_id','first_name','last_name','email_id','mobile_number','image_url','date_of_birth','created_on','updated_on']


class EmployeeCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = app_models.Employee
        exclude = ['employee_id']