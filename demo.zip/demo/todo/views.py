import sys
from rest_framework import status
from rest_framework.views import APIView
from . import data

class EmployeeView(APIView):
    def get(self, request, *args, **kwargs):
        message = None
        try:
            result, msg, employee_data = data.get_employee_list(request)
            if result:
                message = data.HTTP_REST_MESSAGES['200']
                return data.build_response(status.HTTP_200_OK, message, data=employee_data, errors=dict())
            else:
                return data.build_response(status.HTTP_400_BAD_REQUEST, message, data=employee_data, errors=dict())
        except Exception as e:
            exc_type, exc_obj, exc_traceback = sys.exc_info()
            print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
            message = data.HTTP_REST_MESSAGES['500']
            return data.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())
            
        
    def post(self, request, employee_id=None, *args, **kwargs):
        result = False
        message = None
        try:
            if employee_id:
                result, msg, employee_data = data.edit_employee(request, employee_id)
            else:
                result, msg, employee_data = data.create_employee(request)
            if result:
                message = msg
                return data.build_response(status.HTTP_200_OK, message, data={}, errors=dict())
            else:
                return data.build_response(status.HTTP_400_BAD_REQUEST, message, data=employee_data, errors=dict())
        except Exception as e:
            exc_type, exc_obj, exc_traceback = sys.exc_info()
            print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
            message = data.HTTP_REST_MESSAGES['500']
            return data.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())

    def delete(self, request, employee_id, *args, **kwargs):
        result = False
        message = None
        try: 
            result, msg, employee_data = data.delete_employee(employee_id)
            if result:
                message = msg
                return data.build_response(status.HTTP_200_OK, message, data={}, errors=dict())
            else:
                return data.build_response(status.HTTP_400_BAD_REQUEST, message, data=employee_data, errors=dict())
        except Exception as e:
            exc_type, exc_obj, exc_traceback = sys.exc_info()
            print('Exception at %s:%s' % (exc_traceback.tb_lineno, e))
            message = data.HTTP_REST_MESSAGES['500']
            return data.build_response(status.HTTP_500_INTERNAL_SERVER_ERROR, message, data=dict(), errors=dict())
